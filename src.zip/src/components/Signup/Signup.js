import React, { Component } from 'react';

class Signup extends Component {
    render(){
        return(
            <div>
                <h2>Sign Up</h2>
            </div>
        )
    }
}

export default Signup;